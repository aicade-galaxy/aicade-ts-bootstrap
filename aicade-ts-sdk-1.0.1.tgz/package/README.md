# Aicade TypeScript SDK

A TypeScript SDK that supports React, Vue, and vanilla JavaScript projects.

## Features

- 🚀 Multi-framework support: React, Vue, and vanilla JavaScript
- 📦 Pure logic layer with no view dependencies
- 🔧 Full TypeScript support
- 🧪 Comprehensive test coverage
- 📚 Detailed documentation and examples

## Installation

```bash
npm install aicade-ts-sdk lodash
```

Note: This project uses lodash as a peer dependency. You need to install lodash in your own project.

## Usage

### Basic Usage

```typescript
import { AicadeSDK } from "aicade-ts-sdk";

const sdk = new AicadeSDK();

// Initialize SDK
await sdk.init({
    platform: "react", // or 'vue', 'vanilla'
    config: {
        apiKey: "your-api-key",
        apiUrl: "https://api.aicade.com",
        debug: true,
    },
});

// Execute a method
const result = await sdk.execute("someMethod", { param: "value" });

// Destroy SDK
await sdk.destroy();
```

### React Project

```typescript
import { AicadeSDK } from "aicade-ts-sdk";

const sdk = new AicadeSDK();

await sdk.init({
    platform: "react",
    config: {
        apiKey: "your-api-key",
    },
});
```

### Vue Project

```typescript
import { AicadeSDK } from "aicade-ts-sdk";

const sdk = new AicadeSDK();

await sdk.init({
    platform: "vue",
    config: {
        apiKey: "your-api-key",
    },
});
```

### Vanilla JavaScript Project

```javascript
import { AicadeSDK } from "aicade-ts-sdk";

const sdk = new AicadeSDK();

await sdk.init({
    platform: "vanilla",
    config: {
        apiKey: "your-api-key",
    },
});
```

## API Documentation

### AicadeSDK

#### Methods

- `init(options: InitOptions): Promise<void>` - Initialize the SDK
- `destroy(): Promise<void>` - Destroy the SDK
- `execute(method: string, params?: any): Promise<any>` - Execute an SDK method
- `getConfig(): SDKConfig` - Get current configuration
- `updateConfig(newConfig: Partial<SDKConfig>): void` - Update configuration
- `isReady(): boolean` - Check if initialized
- `on(event: string, callback: Function): void` - Add event listener
- `off(event: string, callback?: Function): void` - Remove event listener

#### Events

- `init` - Emitted when SDK initialization completes
- `destroy` - Emitted when SDK destruction completes
- `error` - Emitted on error
- `success` - Emitted on successful operation

## Development

### Install dependencies

```bash
npm install
```

### Development mode

```bash
npm run dev
```

### Build

```bash
npm run build
```

### Tests

```bash
npm test
```

### Lint

```bash
npm run lint
```

### Formatting

```bash
# Format all code
npm run format

# Check code format
npm run format:check
```

#### VS Code Auto-formatting

The project is configured for VS Code auto-formatting:

1. Recommended extensions:
    - Prettier - Code formatter
    - ESLint
    - TypeScript and JavaScript Language Features

2. Auto-format settings:
    - Format on save (Ctrl+S / Cmd+S)
    - Format on paste
    - Auto-fix ESLint issues

3. Manual formatting:
    - Use shortcut `Shift+Alt+F` (Windows/Linux) or `Shift+Option+F` (Mac)
    - Right-click and choose "Format Document"

4. Workspace configuration:
    - Open the `aicade-ts-sdk.code-workspace` file for the best experience

## Project Structure

```
src/
├── core/           # Core SDK logic
├── adapters/       # Framework adapters
├── types/          # TypeScript type definitions
├── utils/          # Utility functions
├── constants/      # Constant definitions
└── __tests__/      # Test files
```

## License

MIT
